from django.contrib import admin
from .models import Produit

admin.site.register(Produit)
